#include <stdio.h>

int main(){
int x = 0;
x = (x > 0)?10:(x == 0)?20:30;
printf("%d\n", x);
system("pause");
}
