#include <stdio.h>

int main (){
	int x = 19;
	int idade = (x >= 18)?1:0;
	    if (idade == 1){
			printf("Maior de idade\n");
		}else {
			printf("Menor de idade\n");
}
system("pause");
}
