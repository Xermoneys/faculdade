#include <stdio.h>

int main(){
	int a = 5;
	float b = 2;

	system("pause");
}
