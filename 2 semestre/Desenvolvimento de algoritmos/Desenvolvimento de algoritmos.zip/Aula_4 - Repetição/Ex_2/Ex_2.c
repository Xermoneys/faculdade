#include <stdio.h>

int main(){
	int i = 5;
	printf("valor de i com i++: %d\n", i++); //para incremento depois ele exibe o valor inicial e depois incrementa
	printf("valor de i com ++i : %d\n", ++i); //para o incremento antes ele adiciona no valor e depois exibe o valor adicionado
	system("pause");
}
