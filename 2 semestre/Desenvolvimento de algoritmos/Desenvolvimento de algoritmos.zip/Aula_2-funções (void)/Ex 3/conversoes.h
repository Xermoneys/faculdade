//conversoes.h - s� o documento puro
//temperatura
float celsiuspFahrenheit(float c);
float fahrenheitpCelsius(float f);
//dist�ncia
float metrospQuilometros(float m);
float quilometrospMetros(float km);
//tempo
float segundospMinutos(float s);
float minutospSegundos(float min);
