//calculadora.h (diret�rio)

float somar(float a, float b);
float subtrair(float a, float b);
float multiplicar (float a, float b);
float dividir (float a, float b);
