//numero.h
int par(int n);
int primo(int n);
int fatorial(int n);
int max(int a,int b);
int pot(int a, int b);

