#ifndef USUARIOS_H
#define USUARIOS_H

void cadastrarUsuario();
int loginUsuario();

#endif
