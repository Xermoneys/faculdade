#ifndef PRODUTOS_H
#define PRODUTOS_H

void listarProdutos();
void buscarProduto();

#endif
