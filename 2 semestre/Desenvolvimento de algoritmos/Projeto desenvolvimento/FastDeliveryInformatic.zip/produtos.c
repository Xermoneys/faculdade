#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "produtos.h"

#define ARQ_PRODUTOS "produtos.txt"

typedef struct {
    int id;
    char nome[50];
    float preco;
} Produto;

void listarProdutos() {
	/*A fun��o listarProdutos() tem como objetivo exibir todos os produtos dispon�veis no sistema.
	Os dados s�o lidos diretamente do arquivo produtos.txt e apresentados de forma organizada, contendo informa��es como ID, nome, tipo e pre�o de cada item.
	Essa fun��o � fundamental para que o usu�rio tenha uma vis�o geral do cat�logo antes de realizar um pedido, simulando a experi�ncia de navega��o em um site de com�rcio eletr�nico.
*/
    Produto p;
    FILE *f = fopen(ARQ_PRODUTOS, "r");
    if (!f) {
        printf("Nenhum produto encontrado.\n");
        return;
    }

    printf("\n=== Lista de Produtos ===\n");
    while (fscanf(f, "%d;%49[^;];%f\n", &p.id, p.nome, &p.preco) == 3) {
        printf("ID: %d | Nome: %s | Preco: R$ %.2f\n", p.id, p.nome, p.preco);
    }
    fclose(f);
}

void buscarProduto() {
	/*A fun��o buscarProduto() permite que o usu�rio procure por um produto espec�fico no cat�logo da loja virtual.
	A busca � realizada com base no nome ou parte do nome do produto, verificando as informa��es presentes no arquivo produtos.txt.
	Ao localizar o item desejado, o sistema exibe os detalhes do produto, como o nome, o tipo e o pre�o.
	Essa funcionalidade proporciona agilidade na navega��o, permitindo que o usu�rio encontre facilmente os produtos de seu interesse.
*/
    Produto p;
    char busca[50];
    FILE *f = fopen(ARQ_PRODUTOS, "r");
    if (!f) {
        printf("Erro ao abrir arquivo.\n");
        return;
    }

    printf("Digite o nome do produto para buscar: ");
    scanf(" %[^\n]", busca);

    printf("\n=== Resultados ===\n");
    while (fscanf(f, "%d;%49[^;];%f\n", &p.id, p.nome, &p.preco) == 3) {
        if (strstr(p.nome, busca))
            printf("ID: %d | Nome: %s | Pre�o: R$ %.2f\n", p.id, p.nome, p.preco);
    }

    fclose(f);
}
