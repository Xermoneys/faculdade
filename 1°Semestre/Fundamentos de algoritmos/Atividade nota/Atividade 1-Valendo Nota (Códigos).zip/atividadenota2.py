altura = int (input("Digite sua altura em centímetros: "))
if altura >= 150:
    print("Você tem altura suficiente para entrar no brinquedo.")
else:
    print("Desculpe,você não tem altura suficiente pra entrar no brinquedo.")